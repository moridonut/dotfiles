mkdir ~/.vim$
mkdir ~/.vim/colors$
mkdir ~/Documents$
mkdir ~/Documents/vimfiles$
mkdir ~/Documents/vimfiles/tmp$
$
cp ../colors/*.vim ~/.vim/colors$
cp ../_vimrc ~/.vimrc$

