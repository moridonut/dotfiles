# dotfiles
dotfiles for vim




aiaaa:wq

